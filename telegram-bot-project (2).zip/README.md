# TaskBot – Telegram Task Organizer Bot

This Telegram bot helps users manage their tasks. It demonstrates SOLID principles:
- **S**ingle Responsibility
- **O**pen/Closed
- **L**iskov Substitution
- **I**nterface Segregation
- **D**ependency Injection

## Features
- /start – Welcome message
- /addtask <description> – Add a new task
- /listtasks – List your tasks

## Setup
1. Clone this repo.
2. Set environment variables:
   - BOT_USERNAME
   - BOT_TOKEN
3. Build and run:
   ```
   mvn clean install
   mvn exec:java -Dexec.mainClass="com.example.taskbot.TaskBot"
   ```
4. (Optional) Docker:
   ```
   docker build -t taskbot .
   docker run -e BOT_USERNAME=... -e BOT_TOKEN=... taskbot
   ```
