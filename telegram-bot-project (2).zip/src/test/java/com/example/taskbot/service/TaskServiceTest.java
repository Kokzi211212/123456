package com.example.taskbot.service;

import com.example.taskbot.model.Task;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    public void testAddAndListTasks() {
        TaskService service = new TaskService();
        Long userId = 123L;
        Task task1 = new Task("Test task 1");
        service.addTask(userId, task1);

        String list = service.listTasks(userId);
        assertTrue(list.contains("Test task 1"));
    }

    @Test
    public void testListTasksEmpty() {
        TaskService service = new TaskService();
        String list = service.listTasks(999L);
        assertEquals("No tasks found.", list);
    }
}
