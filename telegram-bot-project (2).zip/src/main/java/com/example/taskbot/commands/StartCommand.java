package com.example.taskbot.commands;

import org.telegram.telegrambots.meta.api.objects.Update;

public class StartCommand implements Command {
    @Override
    public String getCommandIdentifier() {
        return "/start";
    }

    @Override
    public String handle(Update update) {
        return "Welcome to TaskBot! Use /addtask <task> to add tasks and /listtasks to view your tasks.";
    }
}
