package com.example.taskbot.commands;

import com.example.taskbot.model.Task;
import com.example.taskbot.service.TaskService;
import org.telegram.telegrambots.meta.api.objects.Update;

public class AddTaskCommand implements Command {
    private final TaskService taskService;

    public AddTaskCommand(TaskService taskService) {
        this.taskService = taskService;
    }

    @Override
    public String getCommandIdentifier() {
        return "/addtask";
    }

    @Override
    public String handle(Update update) {
        String[] parts = update.getMessage().getText().split(" ", 2);
        if (parts.length < 2 || parts[1].isBlank()) {
            return "Please provide a task description.";
        }
        Task task = new Task(parts[1]);
        taskService.addTask(update.getMessage().getChatId(), task);
        return "Task added: " + parts[1];
    }
}
