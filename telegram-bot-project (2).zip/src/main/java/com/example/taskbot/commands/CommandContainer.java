package com.example.taskbot.commands;

import com.example.taskbot.service.TaskService;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;

import java.util.HashMap;
import java.util.Map;

public class CommandContainer {
    private final Map<String, Command> commands = new HashMap<>();
    private final String unknownCommand = "Sorry, I don't know that command.";

    public CommandContainer(TaskService taskService) {
        commands.put("/start", new StartCommand());
        commands.put("/addtask", new AddTaskCommand(taskService));
        commands.put("/listtasks", new ListTasksCommand(taskService));
    }

    public String handle(Update update) {
        String message = update.getMessage().getText().trim();
        String[] parts = message.split(" ", 2);
        return commands.getOrDefault(parts[0], cmd -> unknownCommand).handle(update);
    }

    public SendMessage buildMessage(Update update, String text) {
        return new SendMessage(update.getMessage().getChatId().toString(), text);
    }
}
