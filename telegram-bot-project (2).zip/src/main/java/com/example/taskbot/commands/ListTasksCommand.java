package com.example.taskbot.commands;

import com.example.taskbot.service.TaskService;
import org.telegram.telegrambots.meta.api.objects.Update;

public class ListTasksCommand implements Command {
    private final TaskService taskService;

    public ListTasksCommand(TaskService taskService) {
        this.taskService = taskService;
    }

    @Override
    public String getCommandIdentifier() {
        return "/listtasks";
    }

    @Override
    public String handle(Update update) {
        return taskService.listTasks(update.getMessage().getChatId());
    }
}
