package com.example.taskbot.commands;

import org.telegram.telegrambots.meta.api.objects.Update;

public interface Command {
    String getCommandIdentifier();
    String handle(Update update);
}
