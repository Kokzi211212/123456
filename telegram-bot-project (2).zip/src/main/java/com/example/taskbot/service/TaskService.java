package com.example.taskbot.service;

import com.example.taskbot.model.Task;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TaskService {
    private final Map<Long, List<Task>> userTasks = new ConcurrentHashMap<>();

    public void addTask(Long userId, Task task) {
        userTasks.computeIfAbsent(userId, k -> new ArrayList<>()).add(task);
    }

    public String listTasks(Long userId) {
        List<Task> tasks = userTasks.getOrDefault(userId, Collections.emptyList());
        if (tasks.isEmpty()) {
            return "No tasks found.";
        }
        StringBuilder sb = new StringBuilder("Your tasks:
");
        tasks.forEach(t -> sb.append("- ").append(t.getDescription()).append(" (")
                .append(t.getCreatedAt()).append(")
"));
        return sb.toString();
    }
}
