package com.example.taskbot.model;

import java.time.LocalDateTime;

public class Task {
    private final String description;
    private final LocalDateTime createdAt;

    public Task(String description) {
        this.description = description;
        this.createdAt = LocalDateTime.now();
    }

    public String getDescription() { return description; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
