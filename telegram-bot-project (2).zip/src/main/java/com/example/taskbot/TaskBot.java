package com.example.taskbot;

import com.example.taskbot.commands.CommandContainer;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.objects.Update;

public class TaskBot extends TelegramLongPollingBot {
    private final CommandContainer container;

    public TaskBot(CommandContainer container) {
        this.container = container;
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            String response = container.handle(update);
            if (response != null) {
                executeAsync(container.buildMessage(update, response));
            }
        }
    }

    @Override
    public String getBotUsername() {
        return System.getenv("BOT_USERNAME");
    }

    @Override
    public String getBotToken() {
        return System.getenv("BOT_TOKEN");
    }
}
